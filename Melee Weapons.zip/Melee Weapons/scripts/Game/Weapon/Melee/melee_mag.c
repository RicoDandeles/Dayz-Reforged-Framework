// Script File
class MagazineWell65x39C_SampleWeaponClass {}
MagazineWell65x39C_SampleWeaponClass MagazineWell65x39C_SampleWeaponSource;

class MagazineWell65x39C_SampleWeapon : BaseMagazineWell
{
}